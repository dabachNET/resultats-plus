<?php 
ini_set('display_errors', 'off');
error_reporting(0);
?>
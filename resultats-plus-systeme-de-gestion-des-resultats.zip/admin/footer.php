</div>
</section>	



<!-- start footer Area -->		
			<footer class="footer-area mt-40" >
				<div class="container">
					
					<div class="footer-bottom row">
						<p class="footer-text m-0 col-lg-6 col-md-12 pb-25 ">
Copyright &copy; 2019 All rights reserved <a href="<?php echo BASE_PATH; ?>" target="_blank"><?php echo $info_row['school_name']; ?></a> | Powered by <a href="https://dabach.net/resultats_plus/" target="_blank">Résultats PLUS</a>
						</p>
					</div>
				</div>
			</footer>	
<!--
    Powered by Résultats PLUS
    Système de gestion des résultats 
    www.dabach.net
    dabach.net@gmail.com
-->



			<script src="<?php echo BASE_PATH; ?>libs/js/bootstrap.min.js"></script>			

  			<script src="<?php echo BASE_PATH; ?>libs/js/easing.min.js"></script>			
			
			<script src="<?php echo BASE_PATH; ?>libs/js/superfish.min.js"></script>	
			
			<script src="<?php echo BASE_PATH; ?>libs/js/jquery.magnific-popup.min.js"></script>	
			
			<script src="<?php echo BASE_PATH; ?>libs/js/jquery.counterup.min.js"></script>			
				
			<script src="<?php echo BASE_PATH; ?>libs/js/main.js"></script>	

<?php // $connect = null; ?>		

	</body>
</html>
